<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$massage = $_POST['massage'];
// Insert data into database
$sql = "INSERT INTO visitors (name, email, phone, massage) VALUES ('$name',
'$email', '$phone', '$massage')";
if ($conn->query($sql) === TRUE) {
echo "Masage Submited Successfully";
} else {
echo "Error: user not created " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>